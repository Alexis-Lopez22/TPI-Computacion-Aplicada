#!/bin/bash

if [ "$1" = "-help" ]; then
    echo "Uso:"
    echo "./backup_full.sh ORIGEN DESTINO"
    echo "Ejemplo:"
    echo "./backup_full.sh /var/log /backup_dir"
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Error: debe indicar origen y destino."
    echo "Use -help para obtener ayuda."
    exit 1
fi

origen=$1
destino=$2

history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl TPServer
clear
hostnamectl set-hostname TPServer
hostnamectl
clear
cat /etc/os-release 
cat /etc/apt/sources.list
clear
apt update
apt upgrade
apt autoremove
clear
vim /etc/apt/sources.list
clear
vim /etc/apt/sources.list
clear
clear
apt update
clear
apt full-upgrade
lsb_release -a
exit
scp /root/Material_Adicional_TPVMCA/clave_privada.txt agape@192.168.1.3:C:\Users\agape\Desktop\clave_privada.txt
exit
exit
cl
clear
apt install apache2 mariadb-server php libapache2-mod-php php-mysql -y
clear
systemctl enable apache2
systemctl start apache2
systemctl status apache2
clear
systemctl enable mariadb
systemctl start mariadb
systemctl status mariadb
clar
clear
apache2 -v
php -v
mariadb --version
ls /root/Material_Adicional_TPVMCA
clear
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls -l /var/www/html/
mariadb < /root/Material_Adicional_TPVMCA/db.sql
mariadb -u lcars -p
clear
systemctl restart apache2
systemctl restart mariadb
history
clear
ls -l /var/www/html/
mv /var/www/html/index.html /var/www/html/index.htmlbk13062026
ls -l /var/www/html/
chown www-data:www-data /var/www/html/index.php /var/www/html/logo.png
chmod 644 /var/www/html/index.php /var/www/html/logo.png
ls -l /var/www/html/
systemctl restart apache2
systemctl status apache2
clear
ip a
clear
nano /etc/network/interfaces
nano /etc/network/interfaces
systemctl restart networking
ipa
ip a
ping 8.8.8.8
clear
shutdown
ls /root/
clear
apt update
apt install openssh-server -y
systemctl status ssh
clear
systemctl  enable ssh
systemctl start ssh
systemctl status ssh
ls -al /root/
ls /root/
clear
tar -xvzf /root/Material_Adicional_TPVMCA.tar.gz
ls -la /root/.ssh/
cd /root/.ssh/
ls -la
cd /root/
ls -la
cd /root/.ssh
clear
cd
clear
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.shh/
clear
mkdir -p /root/.ssh
chmod 700 /root/.ssh
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.shh/
clear
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/
ls -al /root/.ssh/
chmod 700 /root/.ssh/clave_publica.pub 
ls -al /root/.ssh/
clear
clear
rm -rf /root/.ssh/clave_publica.pub 
ls /root/.ssh/
ls -ak /root/.ssh/
ls -al /root/.ssh/
cat /root/Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys
ls -al /root/.ssh/
clear
chmod 600 /root/.ssh/authorized_keys 
ls -la /root/.ssh/authorized_keys 
chmod 700 /root/.ssh/authorized_keys 
ls -la /root/.ssh/authorized_keys 
clear
nano /etc/ssh/sshd_config
clear
apt install nano
clear
nano /etc/ssh/sshd_config
clear
systemctl restart ssh
systemctl status ssh
ip a
ls -la /root/.ssh/
ls /root/Material_Adicional_TPVMCA/
clear
ls /root/Material_Adicional_TPVMCA/
ip a
cls
clear
ls /root/Material_Adicional_TPVMCA/
cd /root/Material_Adicional_TPVMCA/
pwd
clear
cat /root/Material_Adicional_TPVMCA/clave_privada.txt 
clear
clear
nano /etc/fstab 
nano /etc/fstab 
clear
blkid /dev/sdc1
blkid /dev/sdc2
nano /etc/fstab 
unmount /www_dir
clear
umount /www_dir
umount /backup_dir
mount -a
df -h
cp /root/Material_Adicional_TPVMCA/index.php /www_dir/
cp /root/Material_Adicional_TPVMCA/logo.png /www_dir/
ls -l /www_dir
chown -R www-data:www-data /www_dir

clear
nano /etc/apache2/sites-available/000-default.conf
nano /etc/apache2/sites-available/000-default.conf
clear
nano /etc/apache2/apache2.conf
history
clear
nano /etc/apache2/sites-available/000-default.conf 
clear
cd /var/www/html/
ls
rm index.php 
rm logo.png 
mv index.htmlbk13062026 index.html
ls
clear
apache2ctl configtest
systemctl restart apache2
clear
vim 
nano /etc/network/interfaces
cd
ls /proc/
ls -l /proc/
ls -l /proc/ | grep partitions
clear
ls -l /proc/ | grep partitions
mkdir /opt/particion
cat /proc/partitions >> /opt/particion/
cd /opt/
rm particion
rm -rf particion
clear
touch /opt/particion
ls
cat /proc/partitions >> /opt/particion
cat particion
clear
cd
clear
ls /proc/ | grep partitions 
cat /proc/partitions 
clear
nano backup_full.sh
mkdir /opt/scripts
nano /opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh /var/log/ /backup_dir
cat /backup_dir/logbkp20260613.tar.gz 
exit

#!/bin/bash


case "$1" in
    -help|-h|--help)
        echo "===================================="
        echo "      AYUDA BACKUP_FULL.SH"
        echo "===================================="
        echo "Uso:"
        echo "  $0 ORIGEN DESTINO"
        echo ""
        echo "Parámetros:"
        echo "  ORIGEN   Directorio a respaldar"
        echo "  DESTINO  Directorio donde guardar el backup"
        echo ""
        echo "Ejemplos:"
        echo "  $0 /var/log /backup_dir"
        echo "  $0 /www_dir /backup_dir"
        echo ""
        echo "El backup se genera en formato:"
        echo "  nombre_bkp_AAAAMMDD.tar.gz"
        echo ""
        echo "Ejemplo:"
        echo "  log_bkp_20260613.tar.gz"
        exit 0
        ;;
esac


if [ $# -ne 2 ]; then
    echo "Error: debe indicar origen y destino."
    echo "Use -help para obtener ayuda."
    exit 1
fi


origen=$1
destino=$2

if [ ! -d "$origen" ]
then
    echo "Error: el directorio origen no existe."
    exit 1
fi

if [ ! -d "$destino" ]
then
    echo "Error: el directorio destino no existe."
    exit 1
fi

if ! command -v tar >/dev/null 2>&1
then
    echo "Error: tar no está instalado."
    exit 1
fi

# Obtener nombre del directorio sin la ruta
nombre=$(basename "$origen")

# Fecha AAAAMMDD
fecha=$(date +%Y%m%d)

# Nombre del archivo de backup
archivo="${nombre}_bkp_${fecha}.tar.gz"

# Crear backup
tar -czf "$destino/$archivo" "$origen"


if [ $? -eq 0 ]
then
    echo "Backup realizado correctamente."
    echo "Archivo generado: $destino/$archivo"
else
    echo "Error al realizar el backup."
    exit 1
fi
